<?php

/**
 *
 * @package templates/default
 */

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<p>
    <b>Restore backup mode is enabled</b> so most options are disabled.<br>
    If you want to activate these options to change the migration website you need to restart the installer and deactivate the <b>Restore backup mode</b> option
</p>